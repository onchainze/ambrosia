# Ambrosia

Assistente culinário da família Santos Guerra: app web num único ficheiro (`index.html`) para planear as refeições da semana, em português.

## Funcionalidades
- Receitas por tipo (Carne, Peixe, Sopa, Massa e arroz, Vegetariano, Pequeno-almoço, Sobremesa)
- Pesquisa por receita ou ingrediente, e filtros por tempo, calorias, proteína, açúcar e vegetariano
- Visualização em cartões grandes, médios, pequenos ou em lista
- Informação nutricional aproximada por pessoa
- Plano semanal (pequeno-almoço, almoço e jantar), com sugestão automática
- Lista de compras automática, por secção do supermercado
- Exportar receitas e lista de compras em texto, e o calendário e a lista em PDF ou imagem
- Funciona no telemóvel e pode ser adicionada ao ecrã principal

Os dados (plano, favoritos, lista de compras, forma de visualização) ficam guardados no navegador de cada aparelho.

## Como publicar com GitHub Pages
1. Crie um repositório **público** no GitHub e carregue todos os ficheiros desta pasta.
2. Abra **Settings > Pages**.
3. Em "Build and deployment", escolha **Deploy from a branch**, a branch **main** e a pasta **/ (root)**, e guarde.
4. Ao fim de um ou dois minutos, a app fica em `https://O-SEU-UTILIZADOR.github.io/NOME-DO-REPOSITORIO/`.

## Atualizar
Substitua o `index.html` no repositório (Add file > Upload files, com o mesmo nome). A página atualiza sozinha.

## Ligações para receitas
Cada receita tem a sua própria ligação, e o botão **Partilhar** (na página da receita) envia-a ou copia-a. O formato é o endereço da app seguido de `#` e do id da receita, por exemplo `https://O-SEU-UTILIZADOR.github.io/NOME-DO-REPOSITORIO/#peru-arroz`. Ao abrir a ligação, a receita aparece como uma página própria, com o botão para voltar às receitas.
Também existem `#receitas`, `#semana` e `#compras` para as três páginas principais.

## Fotografias das receitas
A foto dos bifes de peru já vai **dentro do `index.html`**, por isso aparece mesmo que a pasta `fotos` não esteja no repositório.

Para acrescentar mais fotos:
1. Prepare cada foto em formato 4:3 (paisagem), por exemplo 1200×900 px, em JPG, com o prato ao centro e alguma margem à volta. Assim os cartões, quadrados ou 4:3, mostram o prato inteiro.
2. Guarde-a na pasta `fotos` com o id da receita, por exemplo `p-bacalhau-bras.jpg`. A lista de ids está em `fotos/lista-de-receitas.txt`.
3. No início do `index.html`, acrescente o id à lista `FOTOS`, por exemplo `const FOTOS=[`peru-arroz`,`p-bacalhau-bras`];`.
4. Se substituir uma foto por outra com o mesmo nome, aumente o número em `const FOTO_V=2;` para o navegador não mostrar a antiga guardada em cache.

Se uma foto da lista `FOTOS` não for encontrada, a receita mostra a indicação "Foto não encontrada". Isso quer dizer que o ficheiro não está em `fotos/id-da-receita.jpg`.

Use apenas fotografias suas ou com licença livre, e indique o autor quando a licença o pedir.

## Receitas e fontes
As receitas são versões em português escritas para esta app, com valores nutricionais aproximados.
As que indicam uma fonte (Jamie Oliver, Pingo Doce) são inspiradas nos pratos dessas fontes, com ligação para a receita original no detalhe da receita. O texto das receitas originais não está incluído.
